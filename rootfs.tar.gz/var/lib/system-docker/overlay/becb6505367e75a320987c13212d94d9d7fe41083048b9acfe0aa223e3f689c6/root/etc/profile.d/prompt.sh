export PS1='[\u@\h \W]\$ '
