#!/bin/bash

exec ntpd --nofork -g
