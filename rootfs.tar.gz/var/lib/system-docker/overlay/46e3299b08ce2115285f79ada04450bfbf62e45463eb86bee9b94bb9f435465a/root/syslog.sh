#!bin/bash

set -x -e

exec rsyslogd -n
